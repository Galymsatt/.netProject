﻿using Microsoft.EntityFrameworkCore;
using My.WebApp.Core.Models.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace My.WebApp.Core.Repository.Sql
{
    public class TaxDbContext : DbContext
    {
        public TaxDbContext()
        {
            Database.EnsureCreated();
        }

        public TaxDbContext(DbContextOptions<TaxDbContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //optionsBuilder.UseSqlServer(@"Server=.;Database=TaxCalculator;Trusted_Connection=True;MultipleActiveResultSets=true");
                //optionsBuilder.UseSqlServer("server=localhost;port=3307;userid=root;password=;database=TaxCalculator;");
                //optionsBuilder.UseSqlServer(@"Server=localhost;Database=TaxCalculator;Trusted_Connection=True;MultipleActiveResultSets=true;");
                //optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=TaxCalculator;Trusted_Connection=True;");
                //optionsBuilder.UseSqlServer(@"Server=localhost;Database=TaxCalculator;Trusted_Connection=True;MultipleActiveResultSets=true; User Id = root; Password =;");
                optionsBuilder.UseMySql("server=localhost;port=3307;userid=root;password=;database=TaxCalculator;");

            }
        }

        public DbSet<LupRate> LupRate { get; set; }
        public DbSet<LupCalculationType> LupCalculationType { get; set; }
        public DbSet<LupPostalCode> LupPostalCode { get; set; }
        public DbSet<TaxCalculation> TaxCalculation { get; set; }
    }
}
